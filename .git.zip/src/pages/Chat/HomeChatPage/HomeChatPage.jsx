import React from 'react'

const HomeChatPage = () => {
  return (
    <div>
      HomeChatPage
    </div>
  )
}

export default HomeChatPage
