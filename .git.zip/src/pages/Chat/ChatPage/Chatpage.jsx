import React from 'react'

const Chatpage = () => {
  return (
    <div>
      ChatPage
    </div>
  )
}

export default Chatpage
