const User=require("./userSchema");
const Project=require("./projectSchema");
const Bugs=require("./bugsSchema");

module.exports={
    User,
    Project,
    Bugs
}