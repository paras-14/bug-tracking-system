const loginSignupController=require("./loginSignUp");
const projectController=require("./projects.cntrl");
const bugsController=require("./bug.cntrl");

module.exports={
    loginSignupController,
    projectController,
    bugsController
}